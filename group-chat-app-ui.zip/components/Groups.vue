<template>
  <div class="relative w-full h-full pt-4">
    <div class="md:px-4 px-3 absolute top-0 pt-4 inset-x-0 z-[105]">
      <div class="w-full flex justify-between px-3">
        <div><p class="text-gray-50 font-bold text-xl">Groups</p></div>
        <div class="flex items-center gap-4">
          <button class="text-gray-400" @click="showCreateGroup()">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="25"
              height="25"
              viewBox="0 0 24 24"
            >
              <path
                fill="currentColor"
                d="M11 13v3q0 .425.288.713T12 17t.713-.288T13 16v-3h3q.425 0 .713-.288T17 12t-.288-.712T16 11h-3V8q0-.425-.288-.712T12 7t-.712.288T11 8v3H8q-.425 0-.712.288T7 12t.288.713T8 13zm1 9q-2.075 0-3.9-.788t-3.175-2.137T2.788 15.9T2 12t.788-3.9t2.137-3.175T8.1 2.788T12 2t3.9.788t3.175 2.137T21.213 8.1T22 12t-.788 3.9t-2.137 3.175t-3.175 2.138T12 22m0-2q3.35 0 5.675-2.325T20 12t-2.325-5.675T12 4T6.325 6.325T4 12t2.325 5.675T12 20m0-8"
              />
            </svg>
          </button>
          <button class="text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="28"
              height="28"
              viewBox="0 0 24 24"
            >
              <path
                fill="currentColor"
                stroke="currentColor"
                stroke-linecap="round"
                stroke-width="3"
                d="M12 6h.01M12 12h.01M12 18h.01"
              />
            </svg>
          </button>
        </div>
      </div>

      <div class="relative pt-5">
        <div
          class="absolute inset-y-0 start-0 flex items-center ps-3 pt-[22px] pointer-events-none"
        >
          <svg
            class="w-4 h-4 text-gray-500"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 20 20"
          >
            <path
              stroke="currentColor"
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
            />
          </svg>
        </div>
        <input
          class="block w-full px-4 pb-4 pt-3.5 ps-12 pr-11 h-10 outline-none text-gray-300 text-sm rounded-lg bg-light"
          placeholder="Search"
          required
        />
        <button
          type="submit"
          class="text-gray-400 hidden absolute end-2.5 top-[1.7rem] bottom-2.5"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="28"
            height="28"
            viewBox="0 0 24 24"
          >
            <path
              fill="currentColor"
              d="m12 13.4l-2.9 2.9q-.275.275-.7.275t-.7-.275t-.275-.7t.275-.7l2.9-2.9l-2.9-2.875q-.275-.275-.275-.7t.275-.7t.7-.275t.7.275l2.9 2.9l2.875-2.9q.275-.275.7-.275t.7.275q.3.3.3.713t-.3.687L13.375 12l2.9 2.9q.275.275.275.7t-.275.7q-.3.3-.712.3t-.688-.3z"
            />
          </svg>
        </button>
        <button
          type="submit"
          class="text-gray-400 hidden absolute end-4 top-[1.9rem] bottom-2.5"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="15"
            height="15"
            viewBox="0 0 24 24"
          >
            <g stroke="currentColor">
              <circle
                cx="12"
                cy="12"
                r="9.5"
                fill="none"
                stroke-linecap="round"
                stroke-width="3"
              >
                <animate
                  attributeName="stroke-dasharray"
                  calcMode="spline"
                  dur="1.5s"
                  keySplines="0.42,0,0.58,1;0.42,0,0.58,1;0.42,0,0.58,1"
                  keyTimes="0;0.475;0.95;1"
                  repeatCount="indefinite"
                  values="0 150;42 150;42 150;42 150"
                />
                <animate
                  attributeName="stroke-dashoffset"
                  calcMode="spline"
                  dur="1.5s"
                  keySplines="0.42,0,0.58,1;0.42,0,0.58,1;0.42,0,0.58,1"
                  keyTimes="0;0.475;0.95;1"
                  repeatCount="indefinite"
                  values="0;-16;-59;-59"
                />
              </circle>
              <animateTransform
                attributeName="transform"
                dur="2s"
                repeatCount="indefinite"
                type="rotate"
                values="0 12 12;360 12 12"
              />
            </g>
          </svg>
        </button>
      </div>
    </div>

    <div
      class="w-full mt-[5.5rem] pt-5 max-md:h-full md:h-[76vh] overflow-y-auto overflow-x-hidden sidebar"
    >
      <div class="">
        <GroupItem v-for="group of groups" :key="group.id" :group="group" />
      </div>
    </div>
    <CreateEditChatGroup ref="createGroup" action="add" />
  </div>
</template>

<script setup lang="ts">
import CreateEditChatGroup from "./CreateEditChatGroup.vue";
import GroupItem from "./GroupItem.vue";

const createGroup = ref();
const store = useGroupStore();

const groups = computed(() => store.groups);

onMounted(async () => {
  // const { data, error } = await useAsyncData("groups", () =>
  //   store.listUserGroup().then((listUserGroupsResult) => {
  //     pending.value = false;
  //   })
  // );

  await store.listUserGroup().then((listUserGroupsResult) => {
    // pending.value = false;
  });
});

const showCreateGroup = () => {
  createGroup.value.showModal();
};
</script>
